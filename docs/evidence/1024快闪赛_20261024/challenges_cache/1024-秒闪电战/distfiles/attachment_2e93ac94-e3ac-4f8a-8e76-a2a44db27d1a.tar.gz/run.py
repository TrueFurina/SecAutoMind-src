#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""闪电引擎 — 一台只有 6 条指令的栈式机器。

用法：
    python3 run.py tape.txt                # 默认能量 512（跑一半就趴窝）
    python3 run.py tape.txt --energy 1024  # 满能量

指令集（纸带每行一条）：
    PUSH n   把整数 n 压栈
    POP      弹出栈顶
    DUP      复制栈顶
    SWAP     交换栈顶两个元素
    XOR      弹出两个数，压回它们的异或
    EMIT     弹出栈顶并按 Unicode 码点输出
"""
import argparse
import sys

INSTRUCTIONS = ("PUSH", "POP", "DUP", "SWAP", "XOR", "EMIT")


def run(path: str, energy: int) -> None:
    with open(path, encoding="ascii") as fh:
        program = [line.split("#", 1)[0].strip() for line in fh]
    program = [line for line in program if line]

    stack: list[int] = []
    spent = 0
    for lineno, line in enumerate(program, 1):
        if spent >= energy:
            print(f"\n[engine] 能量耗尽（{spent}/{len(program)} 条指令没跑完）。"
                  f"提示：--energy 与纸带等长才是满能量。", file=sys.stderr)
            sys.exit(2)
        spent += 1
        op, _, arg = line.partition(" ")
        if op == "PUSH":
            stack.append(int(arg))
        elif op == "POP":
            stack.pop()
        elif op == "DUP":
            stack.append(stack[-1])
        elif op == "SWAP":
            stack[-1], stack[-2] = stack[-2], stack[-1]
        elif op == "XOR":
            a, b = stack.pop(), stack.pop()
            stack.append(a ^ b)
        elif op == "EMIT":
            sys.stdout.write(chr(stack.pop()))
        else:
            sys.exit(f"[engine] 第 {lineno} 行不是合法指令: {line!r}")
    print()
    print(f"[engine] {len(program)} 条指令全部执行完毕，能量 {spent}/{energy}。", file=sys.stderr)


def main() -> None:
    parser = argparse.ArgumentParser(description="闪电引擎：6 指令栈机")
    parser.add_argument("tape", help="纸带文件（每行一条指令）")
    parser.add_argument("--energy", type=int, default=512,
                        help="能量预算（每执行一条指令消耗 1 点）")
    args = parser.parse_args()
    if args.energy <= 0:
        sys.exit("[engine] 能量必须为正")
    run(args.tape, args.energy)


if __name__ == "__main__":
    main()
