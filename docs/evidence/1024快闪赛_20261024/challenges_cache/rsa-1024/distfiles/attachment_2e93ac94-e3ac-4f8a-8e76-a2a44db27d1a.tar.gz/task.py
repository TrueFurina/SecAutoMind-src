#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""rsa1024.py — 从某运维终端里翻出来的加密脚本（附件原件，未改动）。

输出已经抄在 output.txt 里。secret 部分当时就被删了。
"""
from Crypto.Util.number import bytes_to_long

# 那天晚上熵源坏了。两个素数几乎是同一时刻出生的——
# 生成器只在小得可怜的抖动范围内找下一个素数。
p = BROKEN_GET_CLOSE_PRIME(512)          # 512-bit, p % 4 == 3
q = BROKEN_NEXT_PRIME_AFTER(p, jitter)   # 同样 512-bit, q % 4 == 3, 和 p 只差一点点
assert p % 4 == 3 and q % 4 == 3

n = p * q          # 1024-bit 模数
e = 1024           # 为什么是 1024？因为是活动主题数字。别问。

m = bytes_to_long(FLAG.ljust(127, b"."))   # FLAG 右侧用 '.' 补齐到 127 字节
c = pow(m, e, n)

print(f"{n = }")
print(f"{e = }")
print(f"{c = }")
